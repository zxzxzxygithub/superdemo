package com.fkzhang.wechatxposed;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.text.TextUtils;
import com.fkzhang.xposed.a.c;
import com.fkzhang.xposed.a.d;
import com.fkzhang.xposed.hook.WxCoreLoader;
import com.fkzhang.xposed.hook.h;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import java.io.File;
import java.util.Arrays;
import java.util.HashSet;

public class b
  implements h
{
  private static final com.fkzhang.xposed.a.g a = new com.fkzhang.xposed.a.g("com.fkzhang.wechatxposed");
  private static final HashSet<String> b = new HashSet();
  private static final HashSet<String> c = new HashSet();
  
  static
  {
    String str = a.a(a.u, "");
    if (!TextUtils.isEmpty(str)) {
      b.addAll(Arrays.asList(str.split(";")));
    }
    str = a.a(a.w, "");
    if (!TextUtils.isEmpty(str)) {
      c.addAll(Arrays.asList(str.split(";")));
    }
  }
  
  private void a(String paramString)
  {
    if ((TextUtils.isEmpty(paramString)) || (paramString.startsWith("/"))) {
      return;
    }
    com.fkzhang.xposed.a.b.a(new File(paramString));
  }
  
  public void a(final XC_LoadPackage.LoadPackageParam paramLoadPackageParam, final String paramString)
  {
    if (((!paramString.contains("com.tencen")) || (!paramString.contains("mm"))) && (!b.contains(paramString))) {}
    for (;;)
    {
      return;
      if ((!c.contains(paramLoadPackageParam.processName)) && (((paramLoadPackageParam.isFirstApplication) && (paramLoadPackageParam.processName.equals(paramLoadPackageParam.packageName))) || (!paramLoadPackageParam.processName.startsWith(paramLoadPackageParam.packageName)))) {
        try
        {
          Object localObject1 = (Context)XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.app.ActivityThread", null), "currentActivityThread", new Object[0]), "getSystemContext", new Object[0]);
          Context localContext1 = ((Context)localObject1).createPackageContext(paramString, 2);
          Context localContext2 = ((Context)localObject1).createPackageContext("com.fkzhang.wechatxposed", 2);
          if (!com.fkzhang.xposed.a.b.a(localContext2))
          {
            localObject1 = localContext1.getPackageManager().getPackageInfo(paramString, 0);
            final Object localObject2 = ((PackageInfo)localObject1).versionName;
            final int i = ((PackageInfo)localObject1).versionCode;
            ClassLoader localClassLoader = getClass().getClassLoader();
            localObject1 = localObject2;
            if (TextUtils.isEmpty((CharSequence)localObject2))
            {
              if (paramString.equals("com.tencent.mm4")) {
                localObject1 = "6.3.5";
              }
            }
            else
            {
              localObject2 = localObject1;
              if (((String)localObject1).equals("9.0")) {
                localObject2 = "6.3.9";
              }
              localObject1 = new ContentValues();
              ((ContentValues)localObject1).put(a.n, Integer.valueOf(2));
              ((ContentValues)localObject1).put(a.H, Integer.valueOf(i));
              ((ContentValues)localObject1).put(a.I, (String)localObject2);
              ((ContentValues)localObject1).put(a.G, paramString);
              paramString = new c((ContentValues)localObject1);
              paramString.a("p");
              paramString = new WxCoreLoader(localClassLoader, localContext1, localContext2, paramString.a());
              new Handler().post(new Runnable()
              {
                public void run()
                {
                  try
                  {
                    XposedBridge.log(paramLoadPackageParam.processName + " loading " + "com.fkzhang.wechatxposed");
                    com.fkzhang.xposed.hook.g.a(paramString, localObject2, i, paramLoadPackageParam.classLoader);
                    d locald = paramString.b();
                    if (!locald.a(new File(paramString.c(), "C")))
                    {
                      b.a(b.this, paramString.c());
                      return;
                    }
                    if (!locald.a(new File(paramString.c(), "L")))
                    {
                      b.a(b.this, paramString.c());
                      return;
                    }
                  }
                  catch (Throwable localThrowable)
                  {
                    XposedBridge.log(localThrowable);
                  }
                }
              });
              return;
            }
          }
        }
        catch (Throwable e)
        {
          XposedBridge.log(e);
        }
      }
    }
  }
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/wechatxposed/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */