package com.fkzhang.xposed.hook;

public abstract interface f
{
  public abstract c a();
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/xposed/hook/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */