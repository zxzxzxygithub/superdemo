package com.fkzhang.xposed.hook;

public abstract interface c
{
  public abstract boolean a(ClassLoader paramClassLoader);
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/xposed/hook/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */