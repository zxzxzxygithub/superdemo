package com.fkzhang.xposed.hook;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Build.VERSION;
import android.text.TextUtils;

import com.fkzhang.xposed.a.b;
import com.fkzhang.xposed.a.d;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.io.File;

public class WxCoreLoader
        implements f {
    private final d a;
    private boolean b;
    private ClassLoader c;
    private final Context d;
    private final Context e;
    private ContentValues f;
    private String g;

    public WxCoreLoader(ClassLoader paramClassLoader, Context paramContext1, Context paramContext2, ContentValues paramContentValues) {
        this.c = paramClassLoader;
        this.d = paramContext1;
        this.e = paramContext2;
        this.f = paramContentValues;
        this.a = new d(paramContext2);
        this.a.b(com.fkzhang.wechatxposed.a.p);
        this.b = false;
        File file = new File(paramContext2.getApplicationInfo().nativeLibraryDir, com.fkzhang.wechatxposed.a.f);
        if (!file.exists()) {
            return;
        }
        try {
            System.load(file.getAbsolutePath());
            e();
            d();
            a(0, new Object[]{paramContext2});
            this.b = true;
            return;
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    private static native Object CallMethod(int paramInt, Object[] paramArrayOfObject);

    private Object a(int paramInt, Object... paramVarArgs) {
        try {
           Object  object = CallMethod(paramInt, paramVarArgs);
            return object;
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
        return null;
    }

    private void d() {
        Object file = c();
        if (TextUtils.isEmpty((CharSequence) file)) {
        }
        do {
            return;
            file = new File((String) file).getParentFile().getParentFile();
            File localFile = new File((File) file, com.fkzhang.wechatxposed.a.C);
            if (localFile.exists()) {
                b.a(localFile);
            }
            file = new File((File) file, com.fkzhang.wechatxposed.a.D);
        } while (!((File) file).exists());
        b.a((File) file);
    }

    private void e() {
        this.g = ((String) a(2, new Object[]{this.d}));
    }

    private Object f() {
        int i = 1;
        try {
            if (Build.VERSION.SDK_INT == 19) {
                i = 0;
            }
            if (!this.b) {
                return null;
            }
            Object localObject1 = "com.fkzhang.wechatxposed" + com.fkzhang.wechatxposed.a.E;
            Object localObject2 = a(1, new Object[]{Integer.valueOf(i), this.c, localObject1});
            if (localObject2 == null) {
                return null;
            }
            if (i == 0) {
            }
            for (localObject1 = new a(this.d.getCacheDir().getAbsolutePath(), this.c, ((Integer) localObject2).intValue()).loadClass((String) localObject1); localObject1 == null; localObject1 = (Class) localObject2) {
                XposedBridge.log("unable to load class");
                return null;
            }
            localObject1 = XposedHelpers.newInstance((Class) localObject1, new Object[]{this.d, this.e, this.f, this.g});
            return localObject1;
        } catch (Throwable localThrowable) {
            XposedBridge.log(localThrowable);
        }
        return null;
    }

    public c a() {
        return new e(f());
    }

    public d b() {
        return this.a;
    }

    public String c() {
        return this.g;
    }
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/xposed/hook/WxCoreLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */