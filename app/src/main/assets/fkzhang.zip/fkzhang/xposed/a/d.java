package com.fkzhang.xposed.a;

import android.content.Context;
import android.content.res.AssetManager;
import android.text.TextUtils;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

public class d
{
  private PublicKey a;
  private Context b;
  private byte[] c;
  private String d;
  private byte[] e;
  
  public d(Context paramContext)
  {
    this.b = paramContext;
  }
  
  private String a(byte[] paramArrayOfByte)
  {
    try
    {
      Object localObject = MessageDigest.getInstance("MD5");
      ((MessageDigest)localObject).update(paramArrayOfByte);
      paramArrayOfByte = ((MessageDigest)localObject).digest();
      localObject = new StringBuilder();
      int j = paramArrayOfByte.length;
      int i = 0;
      while (i < j)
      {
        ((StringBuilder)localObject).append(Integer.toHexString(paramArrayOfByte[i] & 0xFF));
        i += 1;
      }
      paramArrayOfByte = ((StringBuilder)localObject).toString();
      return paramArrayOfByte;
    }
    catch (Throwable paramArrayOfByte)
    {
      paramArrayOfByte.printStackTrace();
    }
    return "";
  }
  
  private byte[] a(InputStream paramInputStream)
  {
    byte[] arrayOfByte = new byte[paramInputStream.available()];
    paramInputStream.read(arrayOfByte);
    paramInputStream.close();
    return arrayOfByte;
  }
  
  private PublicKey b()
  {
    if (this.a == null) {}
    try
    {
      this.a = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(this.e)).getPublicKey();
      return this.a;
    }
    catch (Throwable localThrowable)
    {
      for (;;)
      {
        b.a(localThrowable);
      }
    }
  }
  
  private byte[] c()
  {
    if (this.c != null) {
      return this.c;
    }
    try
    {
      Object localObject2 = new JarFile(this.b.getPackageCodePath());
      Object localObject1 = ((JarFile)localObject2).getJarEntry("classes.dex");
      localObject2 = ((JarFile)localObject2).getInputStream((ZipEntry)localObject1);
      byte[] arrayOfByte = new byte[((InputStream)localObject2).available()];
      while (((InputStream)localObject2).read(arrayOfByte) != -1) {}
      ((InputStream)localObject2).close();
      localObject1 = ((JarEntry)localObject1).getCertificates();
      if ((localObject1 != null) && (localObject1.length > 0))
      {
        this.c = localObject1[0].getEncoded();
        localObject1 = this.c;
        return (byte[])localObject1;
      }
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
    return null;
  }
  
  public String a()
  {
    if (!TextUtils.isEmpty(this.d)) {
      return this.d;
    }
    byte[] arrayOfByte = c();
    if (arrayOfByte == null) {
      return "";
    }
    this.d = a(arrayOfByte);
    return this.d;
  }
  
  public boolean a(File paramFile)
  {
    try
    {
      boolean bool = a(new FileInputStream(paramFile), new FileInputStream(new File(paramFile.getAbsolutePath() + "_s")));
      return bool;
    }
    catch (Throwable paramFile)
    {
      b.a(paramFile);
    }
    return false;
  }
  
  public boolean a(InputStream paramInputStream1, InputStream paramInputStream2)
  {
    paramInputStream2 = a(paramInputStream2);
    Signature localSignature = Signature.getInstance("SHA1withRSA", "BC");
    localSignature.initVerify(b());
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramInputStream1);
    byte[] arrayOfByte = new byte['ࠀ'];
    while (localBufferedInputStream.available() != 0) {
      localSignature.update(arrayOfByte, 0, localBufferedInputStream.read(arrayOfByte));
    }
    paramInputStream1.close();
    localBufferedInputStream.close();
    return localSignature.verify(paramInputStream2);
  }
  
  public byte[] a(String paramString)
  {
    try
    {
      paramString = this.b.getAssets().open(paramString);
      byte[] arrayOfByte = new byte[paramString.available()];
      paramString.read(arrayOfByte);
      paramString.close();
      return arrayOfByte;
    }
    catch (Throwable paramString)
    {
      b.a(paramString);
    }
    return null;
  }
  
  public void b(String paramString)
  {
    this.e = a(paramString);
  }
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/xposed/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */