package com.fkzhang.xposed.a;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Debug;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.Toolbar.b;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class b
{
  public static int a(int paramInt)
  {
    return (int)(paramInt * Resources.getSystem().getDisplayMetrics().density);
  }
  
  public static Menu a(Activity paramActivity, LinearLayout paramLinearLayout, String paramString)
  {
    Toolbar toobar
            = new Toolbar(paramActivity);
    toobar.setLayoutParams(new Toolbar.LayoutParams(-1, -2));
    toobar.setBackgroundColor(Color.parseColor("#2196F3"));
    if (!TextUtils.isEmpty(paramString))
    {
      toobar.setTitle(paramString);
      toobar.setTitleTextColor(Color.parseColor("#FFFFFF"));
    }
    a(paramLinearLayout, paramActivity);
    return toobar.getMenu();
  }
  
  public static a a(Activity paramActivity, String paramString, final List<String> paramList, boolean paramBoolean1, boolean paramBoolean2, final c paramc)
  {
    try
    {
      final Object localObject1 = new Builder(paramActivity);
      int i = a(15);
      LinearLayout localLinearLayout1 = new LinearLayout(paramActivity);
      final Object localObject2 = new LinearLayout.LayoutParams(-1, -1);
      localLinearLayout1.setGravity(48);
      localLinearLayout1.setOrientation(1);
      localLinearLayout1.setFocusableInTouchMode(true);
      localLinearLayout1.setLayoutParams((ViewGroup.LayoutParams)localObject2);
      paramString = a(paramActivity, localLinearLayout1, paramString);
      LinearLayout localLinearLayout2 = new LinearLayout(paramActivity);
      localLinearLayout2.setGravity(48);
      localLinearLayout2.setOrientation(1);
      localLinearLayout2.setPadding(i, i, i, i);
      localLinearLayout2.setFocusableInTouchMode(true);
      localLinearLayout2.setLayoutParams((ViewGroup.LayoutParams)localObject2);
      localLinearLayout1.addView(localLinearLayout2);
      ListView localListView = new ListView(paramActivity);
      localObject2 = new ArrayAdapter(paramActivity, 17367043, 16908308, paramList);
      localListView.setAdapter((ListAdapter)localObject2);
      localLinearLayout2.addView(localListView, new LinearLayout.LayoutParams(-1, -2));
      ((Builder)localObject1).setView(localLinearLayout1);
      localObject1 = ((Builder)localObject1).setPositiveButton(17039370, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          if (this.a != null) {
            this.a.a();
          }
        }
      }).setNegativeButton(17039360, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {}
      }).create();
      localListView.setOnItemClickListener(new OnItemClickListener()
      {
        public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
        {
          if (this.a) {
            localObject1.dismiss();
          }
          try
          {
            if (paramc != null) {
              paramc.a(paramList.get(paramAnonymousInt));
            }
            return;
          }
          catch (Throwable paramAnonymousAdapterView)
          {
            b.a(paramAnonymousAdapterView);
          }
        }
      });
      if (paramBoolean2) {
        localListView.setOnItemLongClickListener(new OnItemLongClickListener()
        {
          public boolean onItemLongClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, final int paramAnonymousInt, long paramAnonymousLong)
          {
            b.a(this.a, this.a.getString(2131099679), this.a.getString(2131099680), new b.b()
            {
              public void a()
              {
                b.5.this.b.remove(paramAnonymousInt);
                b.5.this.c.notifyDataSetChanged();
              }
              
              public void b() {}
            });
            return true;
          }
        });
      }
      ((AlertDialog)localObject1).show();
      paramActivity = new a();
      paramActivity.a = paramString;
      paramActivity.b = ((ArrayAdapter)localObject2);
      return paramActivity;
    }
    catch (Throwable e)
    {
      a(e);
    }
    return null;
  }
  
  public static String a(String paramString)
  {
    return paramString + Long.toString(System.currentTimeMillis());
  }
  
  public static ArrayList<String> a(Activity paramActivity)
  {
    Object localObject1 = paramActivity.getPackageManager().getInstalledPackages(0);
    ArrayList localArrayList = new ArrayList();
    localObject1 = ((List)localObject1).iterator();
    while (((Iterator)localObject1).hasNext())
    {
      Object localObject2 = (PackageInfo)((Iterator)localObject1).next();
      String str = ((PackageInfo)localObject2).packageName;
      if ((!str.contains("fkzhang")) && (!str.contains("xposed")) && (!str.contains("com.android")) && (!str.contains("com.google")) && (!str.contains("pro.burgerz.wsm.manager")))
      {
        localObject2 = (String)((PackageInfo)localObject2).applicationInfo.loadLabel(paramActivity.getPackageManager());
        localArrayList.add((String)localObject2 + "\n" + str);
      }
    }
    return localArrayList;
  }
  
  public static void a(Activity paramActivity, int paramInt)
  {
    try
    {
      Intent localIntent = new Intent();
      localIntent.setType("image/*");
      localIntent.setAction("android.intent.action.GET_CONTENT");
      localIntent.addCategory("android.intent.category.OPENABLE");
      paramActivity.startActivityForResult(Intent.createChooser(localIntent, paramActivity.getString(2131099694)), paramInt);
      return;
    }
    catch (Throwable paramActivity)
    {
      paramActivity.printStackTrace();
    }
  }
  
  public static void a(Activity paramActivity, Uri paramUri)
  {
    paramUri = new Intent("android.intent.action.VIEW", paramUri);
    try
    {
      paramActivity.startActivity(paramUri);
      return;
    }
    catch (Throwable paramActivity)
    {
      a(paramActivity);
    }
  }
  
  public static void a(Activity paramActivity, String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return;
    }
    Toast.makeText(paramActivity, paramString, 0).show();
  }
  
  public static void a(Activity paramActivity, String paramString, int paramInt)
  {
    if (TextUtils.isEmpty(paramString)) {
      return;
    }
    Toast.makeText(paramActivity, paramString, paramInt).show();
  }
  
  public static void a(Activity paramActivity, String paramString1, String paramString2, b paramb)
  {
    int i = a(15);
    LinearLayout localLinearLayout = new LinearLayout(paramActivity);
    Object localObject = new LinearLayout.LayoutParams(-1, -1);
    localLinearLayout.setGravity(48);
    localLinearLayout.setOrientation(1);
    localLinearLayout.setFocusableInTouchMode(true);
    localLinearLayout.setLayoutParams((ViewGroup.LayoutParams)localObject);
    a(paramActivity, localLinearLayout, paramString1);
    paramString1 = new LinearLayout(paramActivity);
    paramString1.setGravity(48);
    paramString1.setOrientation(1);
    paramString1.setPadding(i, i, i, i);
    paramString1.setFocusableInTouchMode(true);
    paramString1.setLayoutParams((ViewGroup.LayoutParams)localObject);
    localLinearLayout.addView(paramString1);
    localObject = new Builder(paramActivity);
    ((Builder)localObject).setView(localLinearLayout);
    paramActivity = new TextView(paramActivity);
    paramActivity.setText(paramString2);
    paramActivity.setTextSize(30.0F);
    a(paramString1, paramActivity, i);
    ((Builder)localObject).setPositiveButton(17039379, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        paramAnonymousDialogInterface.dismiss();
        if (this.a != null) {
          this.a.a();
        }
      }
    }).setNegativeButton(17039369, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        if (this.a != null) {
          this.a.b();
        }
      }
    }).create().show();
  }
  
  public static void a(Activity paramActivity, boolean paramBoolean)
  {
    TextView localTextView = (TextView)paramActivity.findViewById(2131492980);
    localTextView.setVisibility(8);
    if ((!paramBoolean) && (!a(paramActivity, "de.robv.android.xposed.installer")) && (!a(paramActivity, "pro.burgerz.wsm.manager")))
    {
      localTextView.setVisibility(0);
      localTextView.setText(paramActivity.getString(2131099711));
      localTextView.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if (Locale.getDefault().getLanguage().equals("zh"))
          {
            b.a(this.a, Uri.parse("http://www.baidu.com/s?wd=" + b.a() + " 安装xposed框架"));
            return;
          }
          b.a(this.a, Uri.parse("http://www.google.com/search?q=" + b.a() + " install xposed framework"));
        }
      });
    }
    ((TextView)paramActivity.findViewById(2131492981)).setText(Html.fromHtml(paramActivity.getString(2131099699)));
  }
  
  public static void a(LinearLayout paramLinearLayout, View paramView)
  {
    a(paramLinearLayout, paramView, 0);
  }
  
  public static void a(LinearLayout paramLinearLayout, View paramView, int paramInt)
  {
    paramView.setPadding(0, 0, 0, paramInt);
    paramLinearLayout.addView(paramView, new LinearLayout.LayoutParams(-1, -2));
  }
  
  public static void a(File paramFile)
  {
    if ((paramFile == null) || (!paramFile.exists())) {
      return;
    }
    if (paramFile.isDirectory())
    {
      File[] arrayOfFile = paramFile.listFiles();
      int j = arrayOfFile.length;
      int i = 0;
      while (i < j)
      {
        a(arrayOfFile[i]);
        i += 1;
      }
    }
    try
    {
      paramFile.delete();
      return;
    }
    catch (Throwable e)
    {
      a(e);
    }
  }
  
  public static void a(Throwable paramThrowable)
  {
    paramThrowable.printStackTrace();
    Log.d("Xposed", paramThrowable.toString());
  }
  
  public static boolean a(Context paramContext)
  {
    return (Debug.isDebuggerConnected()) || ((paramContext.getApplicationInfo().flags & 0x2) != 0);
  }
  
  public static boolean a(Context paramContext, String paramString)
  {
    boolean bool = false;
    try
    {
      paramContext = paramContext.createPackageContext(paramString, 2);
      if (paramContext != null) {
        bool = true;
      }
      return bool;
    }
    catch (Throwable e) {}
    return false;
  }
  
  public static Bitmap b(Activity paramActivity, Uri paramUri)
  {
    try
    {
      paramActivity = paramActivity.getContentResolver().openInputStream(paramUri);
      if (paramActivity != null)
      {
        paramUri = BitmapFactory.decodeStream(paramActivity, null, null);
        paramActivity.close();
        return paramUri;
      }
    }
    catch (Throwable e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  private static String b()
  {
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1)) {
      return b(str2);
    }
    return b(str1) + " " + str2;
  }
  
  private static String b(String paramString)
  {
    String str = null;
    if ((paramString == null) || (paramString.length() == 0)) {
      str = "";
    }
    char c;
    do
    {
      return str;
      c = paramString.charAt(0);
      str = paramString;
    } while (Character.isUpperCase(c));
    return Character.toUpperCase(c) + paramString.substring(1);
  }
  
  public static void b(Activity paramActivity, String paramString)
  {
    ((ClipboardManager)paramActivity.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("text", paramString));
  }
  
  public static class a
  {
    public Menu a;
    public ArrayAdapter<String> b;
    
    public void a()
    {
      this.b.notifyDataSetChanged();
    }
  }
  
  public static abstract interface b
  {
    public abstract void a();
    
    public abstract void b();
  }
  
  public static abstract interface c
  {
    public abstract void a();
    
    public abstract void a(Object paramObject);
  }
}


/* Location:              /Users/zhengyongxiang/Downloads/wxmodule-d2j.jar!/com/fkzhang/xposed/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */